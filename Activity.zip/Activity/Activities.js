// Activity#4

const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/labDB')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('Connection Error:', err));

const studentSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true 
  },
  age: { 
    type: Number, 
    required: true, 
    min: 18, 
    max: 60 
  },
  grade: { 
    type: String, 
    required: true 
  }
});

const Student = mongoose.model('Student', studentSchema);

const newStudent = new Student({
  name: 'Zain',   
  age: 20,         
  grade: 'A'
});
newStudent.save()
  .then(() => console.log('Student saved!'))
  .catch(err => console.log('Validation Error:', err));

// Activity#5

const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/labDB')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('Connection Error:', err));


const courseSchema = new mongoose.Schema({
  name: String,
  duration: String
});

const Course = mongoose.model('Course', courseSchema);

const studentSchema = new mongoose.Schema({
  name: String,
  age: Number,
  grade: String,
  enrolledCourse: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Course' 
  }
});

const Student = mongoose.model('Student', studentSchema);

const newCourse = new Course({
  name: 'web tech',
  duration: '6 months'
});

newCourse.save()
  .then(course => {
    const newStudent = new Student({
      name: 'Zain',
      age: 20,
      grade: 'A',
      enrolledCourse: course._id
    });
    return newStudent.save();
  })
  .then(student => {
    console.log('Student saved:', student);

    
    return Student.findOne({ name: 'John Doe' })
      .populate('enrolledCourse');
  })
  .then(student => {
    console.log('Student with populated course:', student);
  })
  .catch(err => console.log('Error:', err));




const mongose = require('mongoose')
mongose.connect('mongodb://localhost:27017/uni')
.then(()=> console.log("Connect to Mongodb"))
.catch(()=> console.error("cannot connect",err))

const studentSchema = new mongose.Schema({
    name : String,
    age : Number,
    grade : String
});
const newstudent = new student({
    name : "Zain",
    age : 90,
    grade : "B"
});
newstudent.save()
.then(() => console.log("Student Save"))
.catch(() => console.log("Error",err))
const student = mongose.model('student',studentSchema);
const students = [
    {name:"zain",age:21,grade:"B"},
    {name:"Adeel",age:22,grade:"C"},
    {nmae:"Rizwan",age:23,grade:"B"}
];
student.insertMany(students)
.then(() => console.log("Students Saved"))
.catch(() => console.log("Error",err));

student.updateMany({name:"Rafy"},{grade:"A"})
student.find()
.then(() => console.log("All students",students))
.catch(() => console.log("Error",err))

student.findByIdAndDelete()

;