const mongoose = require("mongoose");
const connectDB = async () => {
    try {
        await mongoose.connect("mongodb://127.0.0.1:27017/studentDB");
        console.log("MongoDB Connected");
    } catch (error) {
        console.log("Database Error:", error);
        process.exit(1);
    }
};

module.exports = connectDB;